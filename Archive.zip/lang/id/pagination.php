<?php

declare(strict_types=1);

return [
    'next'     => 'Berikutnya &raquo;',
    'previous' => '&laquo; Sebelumnya',
];
