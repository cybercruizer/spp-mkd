- LARAVEL 9
- MYSQL
  
 ########################################################
  
* FITUR
* LOGIN
* MENERAPKAN FITUR NOTIFIKASI DAN WA NOTIFIKASI
* UPLOAD BUKTI PEMBAYARAN
* SEARCH
* DOWNLOAD DAN PRINT PDF

 ########################################################

* PENERAPAN KODE PROGRAM
* MENERAPKAN JOB SCHEDULE
* MENERAPKAN BEBERAPA FORM AJAX
* MENERAPKAN CONVERT TO PDF 
* MENERAPKAN LIFE CYCLE PADA MODEL LARAVEL
* MENERAPKAN SCOPE DAN ATRIBUT
* MENERAPKAN TRAIT DAN HELPER
* MENERAPKAN KOMPONEN

 ########################################################

* AKTOR:
* BENDAHARA
WALI MURID / SISWA

 ########################################################

* BERIKUT SCREEN SHOT, TAMPILAN DARI APLIKASI PEMBAYARAN SPP PADA SMK PURNAMA 1 KOTA JAMBI
* [tampilan aplikasi.pdf](https://github.com/ZepiDarmawanTambunan/lrv_pembayaranspp_smkpurnama1jambi/files/10835239/tampilan.aplikasi.pdf)
